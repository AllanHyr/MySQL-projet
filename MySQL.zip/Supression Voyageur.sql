DELIMITER $$
CREATE PROCEDURE suppressionCascadeVoyageur(IN num_id INT)
BEGIN

DELETE FROM concerne
WHERE fk_voyageur = num_id;

DELETE FROM voyageur
WHERE id_voyageur = num_id
LIMIT 1;

END$$
DELIMITER ;