SELECT count(ville), ville
FROM coordonnées
INNER JOIN voyage ON id_coordonnées = fk_coordonnées_a GROUP BY ville ORDER BY count(ville) desc;