DROP VIEW IF EXISTS tom;
CREATE VIEW tom AS
SELECT genre , id_voyageur
from voyage
INNER JOIN concerne ON concerne.fk_voyage = voyage.id_voyage
INNER JOIN voyageur ON voyageur.id_voyageur = concerne.fk_voyageur
where date_départ > unix_timestamp('2022_06_01');
SELECT genre, count(genre) as total, 
	(count(genre)/(select count(genre) from tom)*100) as "%"
    from tom GROUP BY genre;