select transport_mod, count(transport_mod) as nombre_transport_use
from transport
inner join etape on etape.fk_transport = transport.id_transport
INNER JOIN etape_voyage ON etape_voyage.fk_etape = etape.id_etape
INNER JOIN voyage ON voyage.id_voyage = etape_voyage.fk_voyage
where from_unixtime(date_départ) >= ('2022_09_01')
group by transport_mod
order by count(transport_mod) desc;