DELIMITER $$
CREATE PROCEDURE suppressionCascadeClient(IN num_id INT)
BEGIN

DELETE FROM paiement
WHERE fk_clients = num_id;

DELETE FROM facturation
WHERE fk_clients = num_id;


DELETE FROM clients
WHERE id_clients = num_id
LIMIT 1;

DELETE FROM coordonnées
WHERE id_coordonnées =(SELECT fk_coordonnées_f FROM clients WHERE id_clients = num_id);

DELETE FROM coordonnées
WHERE id_coordonnées =(SELECT fk_coordonnées_l FROM clients WHERE id_clients = num_id);
END$$
DELIMITER ;