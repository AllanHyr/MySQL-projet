DELIMITER $$
CREATE PROCEDURE suppressionCascadeEmploye(IN num_id INT)
BEGIN

DELETE FROM paiement
WHERE fk_facturation = (SELECT id_facturation FROM facturation WHERE fk_employé = num_id);

DELETE FROM facturation
WHERE fk_employé = num_id;

DELETE FROM employé
WHERE id_employé = num_id
LIMIT 1;

DELETE FROM coordonnées
WHERE id_coordonnées =(SELECT fk_coordonnées FROM employé WHERE id_employé = num_id);

END$$
DELIMITER ;