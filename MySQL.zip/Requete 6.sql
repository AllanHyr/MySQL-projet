DROP VIEW IF EXISTS transport_etape;
DROP VIEW IF EXISTS test2;
CREATE VIEW transport_etape AS
SELECT transport_mod, id_etape
FROM transport
INNER JOIN etape ON id_transport = fk_transport;
CREATE VIEW test2 AS
SELECT id_voyage, nb_pt_etape
FROM voyage;
SELECT count(transport_mod), transport_mod
FROM transport_etape
INNER JOIN etape_voyage ON id_etape = fk_etape
INNER JOIN test2 ON id_voyage = fk_voyage where nb_pt_etape= 0 and transport_mod ='avion';