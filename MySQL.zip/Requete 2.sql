select count(ville) as nombre, ville
from clients
inner join coordonnées on id_coordonnées = fk_coordonnées_f
group by ville
ORDER BY nombre DESC;