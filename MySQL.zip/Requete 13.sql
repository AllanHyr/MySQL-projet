SELECT count(ageVoyageur) as nbr_per,
    (count(ageVoyageur)/(SELECT count(ageVoyageur) FROM voyageur)*100) AS "%"
FROM voyage
INNER JOIN concerne ON concerne.fk_voyage = voyage.id_voyage
INNER JOIN voyageur ON voyageur.id_voyageur = concerne.fk_voyageur
WHERE date_départ >= unix_timestamp('2022_06_01') AND ageVoyageur >= "2002_01_01";