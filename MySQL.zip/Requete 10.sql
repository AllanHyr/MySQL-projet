DROP VIEW IF EXISTS prix_etape;
DROP VIEW IF EXISTS forfait_etape;
DROP VIEW IF EXISTS moyen_transp;
CREATE VIEW prix_etape AS
SELECT sum(prix_km* distance) AS prix, id_etape , transport_mod , fk_transport , forfait
FROM transport
INNER JOIN etape ON id_transport = fk_transport GROUP BY id_etape;
CREATE VIEW forfait_etape AS
SELECT if(prix_etape.forfait = 0, prix, 2) AS prix, prix_etape.id_etape, etape.fk_transport , transport_mod
FROM etape
INNER JOIN prix_etape ON etape.id_etape = prix_etape.id_etape;
CREATE VIEW moyen_transp AS
SELECT transport_mod, prix , id_etape
FROM forfait_etape WHERE transport_mod='car';
SELECT avg(prix)
FROM moyen_transp;