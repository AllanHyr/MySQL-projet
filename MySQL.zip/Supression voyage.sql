DELIMITER $$
CREATE PROCEDURE suppressionCascadeVoyage(IN num_id INT)
BEGIN

DELETE FROM etape_voyage
WHERE fk_voyage = num_id;

DELETE FROM concerne
WHERE fk_voyage = num_id;

DELETE FROM paiement
WHERE fk_facturation = (SELECT id_facturation FROM facturation WHERE fk_voyage = num_id);

DELETE FROM facturation
WHERE fk_voyage = num_id;

DELETE FROM voyage
WHERE id_voyage = num_id
LIMIT 1;

END$$
DELIMITER ;